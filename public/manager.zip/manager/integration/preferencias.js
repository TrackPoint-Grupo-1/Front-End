// preferencias.js — versão final e estável
// =======================================================
// LocalStorage Keys:
//   pref_dark -> "on" | "off"
//   pref_filter -> "none" | "protanopia" | "deuteranopia" | "tritanopia" | "alto-contraste"
//   pref_fontsize -> "pref-font-sm|md|lg|xl"
//   pref_highcontrast -> "on" | "off"
// =======================================================

(function () {
    const KEY_DARK = 'pref_dark';
    const KEY_FILTER = 'pref_filter';
    const KEY_FONT = 'pref_fontsize';
    const KEY_CONTRASTE = 'pref_highcontrast';

    // --------------------------
    // APLICAÇÕES
    // --------------------------

    function applyDark(enabled) {
        document.body.classList.toggle('dark-mode', !!enabled);
    }

    function applyFilter(filterName) {
        const filterClasses = [
            'filtro-protanopia',
            'filtro-deuteranopia',
            'filtro-tritanopia',
            'alto-contraste'
        ];
        filterClasses.forEach(c => document.body.classList.remove(c));

        if (filterName && filterName !== 'none') {
            const map = {
                protanopia: 'filtro-protanopia',
                deuteranopia: 'filtro-deuteranopia',
                tritanopia: 'filtro-tritanopia',
                'alto-contraste': 'alto-contraste'
            };
            const cls = map[filterName];
            if (cls) document.body.classList.add(cls);
        }
    }

    function applyFontSize(level) {
        document.body.classList.remove(
            'pref-font-sm',
            'pref-font-md',
            'pref-font-lg',
            'pref-font-xl'
        );
        document.body.classList.add(level);
    }

    function applyHighContrast(enabled) {
        document.body.classList.toggle('pref-high-contrast', !!enabled);
    }

    // --------------------------
    // RESTAURAR CONFIGURAÇÕES
    // --------------------------

    function applySavedPreferences() {
        try {
            applyDark(localStorage.getItem(KEY_DARK) === 'on');
            applyFilter(localStorage.getItem(KEY_FILTER) || 'none');
            applyFontSize(localStorage.getItem(KEY_FONT) || 'pref-font-md');
            applyHighContrast(localStorage.getItem(KEY_CONTRASTE) === 'on');

            // Atualizar UI
            const toggleDark = document.getElementById('toggle-dark');
            if (toggleDark) toggleDark.checked = localStorage.getItem(KEY_DARK) === 'on';

            const selectDaltonismo = document.getElementById('select-daltonismo');
            if (selectDaltonismo) selectDaltonismo.value = localStorage.getItem(KEY_FILTER) || 'none';

            const selectFont = document.querySelector('[data-font="' + localStorage.getItem(KEY_FONT) + '"]');

            const toggleContrast = document.getElementById('toggle-contrast');
            if (toggleContrast) toggleContrast.checked = localStorage.getItem(KEY_CONTRASTE) === 'on';

        } catch (err) {
            console.error('Erro ao aplicar preferências salvas:', err);
        }
    }

    // --------------------------
    // SALVAR CONFIGURAÇÕES
    // --------------------------

    function saveDark(enabled) {
        localStorage.setItem(KEY_DARK, enabled ? 'on' : 'off');
    }

    function saveFilter(filterName) {
        localStorage.setItem(KEY_FILTER, filterName || 'none');
    }

    function saveFontSize(level) {
        localStorage.setItem(KEY_FONT, level);
    }

    function saveHighContrast(enabled) {
        localStorage.setItem(KEY_CONTRASTE, enabled ? 'on' : 'off');
    }

    // --------------------------
    // HOOK DOS CONTROLES
    // --------------------------

    function hookControls() {
        // Dark mode
        const toggleDark = document.getElementById('toggle-dark');
        if (toggleDark && !toggleDark._prefHooked) {
            toggleDark.addEventListener('change', () => {
                applyDark(toggleDark.checked);
                saveDark(toggleDark.checked);
            });
            toggleDark._prefHooked = true;
        }

        // Daltonismo
        const selectDaltonismo = document.getElementById('select-daltonismo');
        if (selectDaltonismo && !selectDaltonismo._prefHooked) {
            selectDaltonismo.addEventListener('change', () => {
                applyFilter(selectDaltonismo.value);
                saveFilter(selectDaltonismo.value);
            });
            selectDaltonismo._prefHooked = true;
        }

        // Tamanho da fonte
        document.querySelectorAll('[data-font]').forEach(btn => {
            if (!btn._prefHooked) {
                btn.addEventListener('click', () => {
                    const level = btn.getAttribute('data-font');
                    applyFontSize(level);
                    saveFontSize(level);
                });
                btn._prefHooked = true;
            }
        });

        // Alto contraste
        const toggleContrast = document.getElementById('toggle-contrast');
        if (toggleContrast && !toggleContrast._prefHooked) {
            toggleContrast.addEventListener('change', () => {
                applyHighContrast(toggleContrast.checked);
                saveHighContrast(toggleContrast.checked);
            });
            toggleContrast._prefHooked = true;
        }
    }

    // --------------------------
    // OBSERVADOR PARA WEB COMPONENTS
    // --------------------------

    function setupMutationObserver() {
        if (window.__prefObserverInstalled) return;
        window.__prefObserverInstalled = true;

        const observer = new MutationObserver(() => {
            applySavedPreferences();
            hookControls();
        });

        observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });

        // SPA + back button
        window.addEventListener('popstate', () => {
            setTimeout(() => {
                applySavedPreferences();
                hookControls();
            }, 150);
        });
    }

    // --------------------------
    // INIT
    // --------------------------

    function init() {
        applySavedPreferences();
        hookControls();
        setupMutationObserver();
    }

    window.preferencias = { init };

    init();
})();
